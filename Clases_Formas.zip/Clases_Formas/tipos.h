//
// Created by J on 08-Nov-19.
//

#ifndef CLASES_FORMAS_TIPOS_H
#define CLASES_FORMAS_TIPOS_H
#include <iostream>
#include <string>
#include <vector>
#include <cmath>

using namespace std;
typedef string TipoString;
typedef double TipoNum;
const double pi = M_PI;
#endif //CLASES_FORMAS_TIPOS_H
