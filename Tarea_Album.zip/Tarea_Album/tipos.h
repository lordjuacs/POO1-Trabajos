//
// Created by J on 31-Oct-19.
//

#ifndef TAREA_ALBUM_TIPOS_H
#define TAREA_ALBUM_TIPOS_H

#include <iostream>
#include <string>
#include <vector>
#include <algorithm>

using namespace std;

#endif //TAREA_ALBUM_TIPOS_H
