
#ifndef LAB109_TIPOS_H
#define LAB109_TIPOS_H

#include <iostream>
using namespace std;

using TipoEntero = int;
typedef string TipoCadena;

#endif //LAB109_TIPOS_H
